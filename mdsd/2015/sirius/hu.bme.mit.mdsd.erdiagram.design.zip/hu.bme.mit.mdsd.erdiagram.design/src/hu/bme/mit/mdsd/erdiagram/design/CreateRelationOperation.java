package hu.bme.mit.mdsd.erdiagram.design;

import java.util.Collection;
import java.util.Map;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.sirius.tools.api.ui.IExternalJavaAction;

import ERDiagram.ERDiagramFactory;
import ERDiagram.Entity;
import ERDiagram.EntityRelationDiagram;
import ERDiagram.Relation;
import ERDiagram.RelationEnding;

public class CreateRelationOperation implements IExternalJavaAction {

	public CreateRelationOperation() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public void execute(Collection<? extends EObject> selections,
			Map<String, Object> parameters) {
		
		Entity source = (Entity) parameters.get("source");
		Entity target = (Entity) parameters.get("target");
		EntityRelationDiagram diagram = (EntityRelationDiagram) parameters.get("container");
		
		Relation relation = ERDiagramFactory.eINSTANCE.createRelation();
		
		RelationEnding leftRelationEnding = ERDiagramFactory.eINSTANCE.createRelationEnding();
		RelationEnding rightRelationEnding = ERDiagramFactory.eINSTANCE.createRelationEnding();
		
		relation.setLeftEnding(leftRelationEnding);
		relation.setRightEnding(rightRelationEnding);
		
		leftRelationEnding.setTarget(source);
		rightRelationEnding.setTarget(target);
		
		leftRelationEnding.setName("undefined");
		rightRelationEnding.setName("undefined");
		
		diagram.getRelations().add(relation);
	}

	@Override
	public boolean canExecute(Collection<? extends EObject> selections) {
		for (EObject eObject : selections) {
			if(!(eObject instanceof Entity)) {				
				return false;
			}
		}
		return true;
	}

}
