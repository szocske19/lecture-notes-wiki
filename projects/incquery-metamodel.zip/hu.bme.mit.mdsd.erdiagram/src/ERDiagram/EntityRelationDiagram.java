/**
 */
package ERDiagram;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Entity Relation Diagram</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link ERDiagram.EntityRelationDiagram#getEntities <em>Entities</em>}</li>
 *   <li>{@link ERDiagram.EntityRelationDiagram#getRelations <em>Relations</em>}</li>
 *   <li>{@link ERDiagram.EntityRelationDiagram#getAttributetypes <em>Attributetypes</em>}</li>
 * </ul>
 * </p>
 *
 * @see ERDiagram.ERDiagramPackage#getEntityRelationDiagram()
 * @model
 * @generated
 */
public interface EntityRelationDiagram extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Entities</b></em>' containment reference list.
	 * The list contents are of type {@link ERDiagram.Entity}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Entities</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Entities</em>' containment reference list.
	 * @see ERDiagram.ERDiagramPackage#getEntityRelationDiagram_Entities()
	 * @model containment="true"
	 * @generated
	 */
	EList<Entity> getEntities();

	/**
	 * Returns the value of the '<em><b>Relations</b></em>' containment reference list.
	 * The list contents are of type {@link ERDiagram.Relation}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Relations</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Relations</em>' containment reference list.
	 * @see ERDiagram.ERDiagramPackage#getEntityRelationDiagram_Relations()
	 * @model containment="true"
	 * @generated
	 */
	EList<Relation> getRelations();

	/**
	 * Returns the value of the '<em><b>Attributetypes</b></em>' containment reference list.
	 * The list contents are of type {@link ERDiagram.AttributeType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Attributetypes</em>' containment reference list isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attributetypes</em>' containment reference list.
	 * @see ERDiagram.ERDiagramPackage#getEntityRelationDiagram_Attributetypes()
	 * @model containment="true"
	 * @generated
	 */
	EList<AttributeType> getAttributetypes();

} // EntityRelationDiagram
