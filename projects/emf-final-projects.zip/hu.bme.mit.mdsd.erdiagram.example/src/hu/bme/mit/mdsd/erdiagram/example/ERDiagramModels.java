package hu.bme.mit.mdsd.erdiagram.example;

import hu.bme.mit.mdsd.ERDiagram.*;

import java.io.IOException;

import org.eclipse.emf.common.util.URI;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.emf.ecore.resource.ResourceSet;
import org.eclipse.emf.ecore.resource.impl.ResourceSetImpl;
import org.eclipse.emf.ecore.xmi.impl.XMIResourceFactoryImpl;

public class ERDiagramModels {

	public void init() {

		ERDiagramPackage.eINSTANCE.eClass();

		Resource.Factory.Registry reg = Resource.Factory.Registry.INSTANCE;
		reg.getExtensionToFactoryMap().put("erdiagram",
				new XMIResourceFactoryImpl());

	}

	public Resource createResource(URI uri) {
		ResourceSet resSet = new ResourceSetImpl();
		Resource resource = resSet.createResource(uri);
		return resource;
	}

	public Resource loadResource(URI uri) {
		ResourceSet resSet = new ResourceSetImpl();
		Resource resource = resSet.getResource(uri, true);
		return resource;
	}

	public void saveResource(Resource resource) {
		try {
			resource.save(null);
		} catch (IOException e) {
			System.out
					.println("The following error occured during saving the resource: "
							+ e.getMessage());
		}
	}

	public EntityRelationDiagram getModelFromResource(Resource resource) {
		return (EntityRelationDiagram) resource.getContents().get(0);
	}

	public EntityRelationDiagram createModel() {

		ERDiagramFactory factory = ERDiagramFactory.eINSTANCE;
		EntityRelationDiagram diagram = factory.createEntityRelationDiagram();

		Entity person = factory.createEntity();
		Attribute name = factory.createAttribute();
		AttributeType attributeType = factory.createAttributeType();

		attributeType.setName("String");
		name.setName("Name");
		name.setType(attributeType);
		person.setName("Person");
		person.getAttributes().add(name);

		diagram.getAttributetypes().add(attributeType);
		diagram.getEntities().add(person);

		return diagram;
	}

	public void printERDiagram(EntityRelationDiagram erdiagram) {
		for (Entity entity : erdiagram.getEntities()) {
			System.out.println(entity.getName());
		}
	}

	public static void main(String[] args) {
		// init
		ERDiagramModels erdiagramModels = new ERDiagramModels();
		erdiagramModels.init();
		// create
		EntityRelationDiagram model = erdiagramModels.createModel();
		// save
		URI uri = URI.createFileURI("C:/workspace/hu.bme.mit.mdsd.erdiagram.example/samplemodel.erdiagram");
		Resource resource = erdiagramModels.createResource(uri);
		resource.getContents().add(model);
		erdiagramModels.saveResource(resource);
		// load
		Resource resource2 = erdiagramModels.loadResource(uri);
		EntityRelationDiagram model2 = erdiagramModels.getModelFromResource(resource2);
		// print
		erdiagramModels.printERDiagram(model2);
	}
}
