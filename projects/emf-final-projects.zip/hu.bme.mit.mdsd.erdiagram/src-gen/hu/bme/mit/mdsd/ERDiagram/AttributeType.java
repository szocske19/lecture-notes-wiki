/**
 */
package hu.bme.mit.mdsd.ERDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute Type</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see hu.bme.mit.mdsd.ERDiagram.ERDiagramPackage#getAttributeType()
 * @model
 * @generated
 */
public interface AttributeType extends NamedElement {
} // AttributeType
