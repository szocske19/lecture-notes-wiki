/**
 */
package hu.bme.mit.mdsd.ERDiagram;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relation Ending</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link hu.bme.mit.mdsd.ERDiagram.RelationEnding#isNullable <em>Nullable</em>}</li>
 *   <li>{@link hu.bme.mit.mdsd.ERDiagram.RelationEnding#getMultiplicity <em>Multiplicity</em>}</li>
 * </ul>
 * </p>
 *
 * @see hu.bme.mit.mdsd.ERDiagram.ERDiagramPackage#getRelationEnding()
 * @model
 * @generated
 */
public interface RelationEnding extends NamedElement {
	/**
	 * Returns the value of the '<em><b>Nullable</b></em>' attribute.
	 * The default value is <code>"false"</code>.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Nullable</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Nullable</em>' attribute.
	 * @see #setNullable(boolean)
	 * @see hu.bme.mit.mdsd.ERDiagram.ERDiagramPackage#getRelationEnding_Nullable()
	 * @model default="false"
	 * @generated
	 */
	boolean isNullable();

	/**
	 * Sets the value of the '{@link hu.bme.mit.mdsd.ERDiagram.RelationEnding#isNullable <em>Nullable</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Nullable</em>' attribute.
	 * @see #isNullable()
	 * @generated
	 */
	void setNullable(boolean value);

	/**
	 * Returns the value of the '<em><b>Multiplicity</b></em>' attribute.
	 * The literals are from the enumeration {@link hu.bme.mit.mdsd.ERDiagram.MultiplicityType}.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Multiplicity</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Multiplicity</em>' attribute.
	 * @see hu.bme.mit.mdsd.ERDiagram.MultiplicityType
	 * @see #setMultiplicity(MultiplicityType)
	 * @see hu.bme.mit.mdsd.ERDiagram.ERDiagramPackage#getRelationEnding_Multiplicity()
	 * @model
	 * @generated
	 */
	MultiplicityType getMultiplicity();

	/**
	 * Sets the value of the '{@link hu.bme.mit.mdsd.ERDiagram.RelationEnding#getMultiplicity <em>Multiplicity</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Multiplicity</em>' attribute.
	 * @see hu.bme.mit.mdsd.ERDiagram.MultiplicityType
	 * @see #getMultiplicity()
	 * @generated
	 */
	void setMultiplicity(MultiplicityType value);

} // RelationEnding
