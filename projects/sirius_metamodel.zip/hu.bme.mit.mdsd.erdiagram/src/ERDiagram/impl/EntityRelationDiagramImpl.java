/**
 */
package ERDiagram.impl;

import ERDiagram.AttributeType;
import ERDiagram.ERDiagramPackage;
import ERDiagram.Entity;
import ERDiagram.EntityRelationDiagram;
import ERDiagram.Relation;

import java.util.Collection;

import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EObject;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.util.EObjectContainmentEList;
import org.eclipse.emf.ecore.util.InternalEList;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Entity Relation Diagram</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * <ul>
 *   <li>{@link ERDiagram.impl.EntityRelationDiagramImpl#getEntities <em>Entities</em>}</li>
 *   <li>{@link ERDiagram.impl.EntityRelationDiagramImpl#getRelations <em>Relations</em>}</li>
 *   <li>{@link ERDiagram.impl.EntityRelationDiagramImpl#getAttributetypes <em>Attributetypes</em>}</li>
 *   <li>{@link ERDiagram.impl.EntityRelationDiagramImpl#getTemporary <em>Temporary</em>}</li>
 * </ul>
 * </p>
 *
 * @generated
 */
public class EntityRelationDiagramImpl extends NamedElementImpl implements EntityRelationDiagram {
	/**
	 * The cached value of the '{@link #getEntities() <em>Entities</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getEntities()
	 * @generated
	 * @ordered
	 */
	protected EList<Entity> entities;

	/**
	 * The cached value of the '{@link #getRelations() <em>Relations</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getRelations()
	 * @generated
	 * @ordered
	 */
	protected EList<Relation> relations;

	/**
	 * The cached value of the '{@link #getAttributetypes() <em>Attributetypes</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttributetypes()
	 * @generated
	 * @ordered
	 */
	protected EList<AttributeType> attributetypes;

	/**
	 * The cached value of the '{@link #getTemporary() <em>Temporary</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getTemporary()
	 * @generated
	 * @ordered
	 */
	protected EList<EObject> temporary;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected EntityRelationDiagramImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return ERDiagramPackage.Literals.ENTITY_RELATION_DIAGRAM;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Entity> getEntities() {
		if (entities == null) {
			entities = new EObjectContainmentEList<Entity>(Entity.class, this, ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES);
		}
		return entities;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Relation> getRelations() {
		if (relations == null) {
			relations = new EObjectContainmentEList<Relation>(Relation.class, this, ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS);
		}
		return relations;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<AttributeType> getAttributetypes() {
		if (attributetypes == null) {
			attributetypes = new EObjectContainmentEList<AttributeType>(AttributeType.class, this, ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES);
		}
		return attributetypes;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<EObject> getTemporary() {
		if (temporary == null) {
			temporary = new EObjectContainmentEList<EObject>(EObject.class, this, ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY);
		}
		return temporary;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES:
				return ((InternalEList<?>)getEntities()).basicRemove(otherEnd, msgs);
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS:
				return ((InternalEList<?>)getRelations()).basicRemove(otherEnd, msgs);
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES:
				return ((InternalEList<?>)getAttributetypes()).basicRemove(otherEnd, msgs);
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY:
				return ((InternalEList<?>)getTemporary()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES:
				return getEntities();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS:
				return getRelations();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES:
				return getAttributetypes();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY:
				return getTemporary();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES:
				getEntities().clear();
				getEntities().addAll((Collection<? extends Entity>)newValue);
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS:
				getRelations().clear();
				getRelations().addAll((Collection<? extends Relation>)newValue);
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES:
				getAttributetypes().clear();
				getAttributetypes().addAll((Collection<? extends AttributeType>)newValue);
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY:
				getTemporary().clear();
				getTemporary().addAll((Collection<? extends EObject>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES:
				getEntities().clear();
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS:
				getRelations().clear();
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES:
				getAttributetypes().clear();
				return;
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY:
				getTemporary().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ENTITIES:
				return entities != null && !entities.isEmpty();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__RELATIONS:
				return relations != null && !relations.isEmpty();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__ATTRIBUTETYPES:
				return attributetypes != null && !attributetypes.isEmpty();
			case ERDiagramPackage.ENTITY_RELATION_DIAGRAM__TEMPORARY:
				return temporary != null && !temporary.isEmpty();
		}
		return super.eIsSet(featureID);
	}

} //EntityRelationDiagramImpl
