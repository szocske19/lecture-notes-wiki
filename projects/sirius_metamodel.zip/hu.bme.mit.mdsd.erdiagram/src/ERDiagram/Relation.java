/**
 */
package ERDiagram;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Relation</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link ERDiagram.Relation#getLeftEnding <em>Left Ending</em>}</li>
 *   <li>{@link ERDiagram.Relation#getRightEnding <em>Right Ending</em>}</li>
 * </ul>
 * </p>
 *
 * @see ERDiagram.ERDiagramPackage#getRelation()
 * @model
 * @generated
 */
public interface Relation extends EObject {
	/**
	 * Returns the value of the '<em><b>Left Ending</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Left Ending</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Left Ending</em>' containment reference.
	 * @see #setLeftEnding(RelationEnding)
	 * @see ERDiagram.ERDiagramPackage#getRelation_LeftEnding()
	 * @model containment="true"
	 * @generated
	 */
	RelationEnding getLeftEnding();

	/**
	 * Sets the value of the '{@link ERDiagram.Relation#getLeftEnding <em>Left Ending</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Left Ending</em>' containment reference.
	 * @see #getLeftEnding()
	 * @generated
	 */
	void setLeftEnding(RelationEnding value);

	/**
	 * Returns the value of the '<em><b>Right Ending</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Right Ending</em>' containment reference isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Right Ending</em>' containment reference.
	 * @see #setRightEnding(RelationEnding)
	 * @see ERDiagram.ERDiagramPackage#getRelation_RightEnding()
	 * @model containment="true"
	 * @generated
	 */
	RelationEnding getRightEnding();

	/**
	 * Sets the value of the '{@link ERDiagram.Relation#getRightEnding <em>Right Ending</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Right Ending</em>' containment reference.
	 * @see #getRightEnding()
	 * @generated
	 */
	void setRightEnding(RelationEnding value);

} // Relation
