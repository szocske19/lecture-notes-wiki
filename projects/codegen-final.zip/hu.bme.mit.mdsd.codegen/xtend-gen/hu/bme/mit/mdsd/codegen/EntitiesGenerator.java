package hu.bme.mit.mdsd.codegen;

import ERDiagram.Attribute;
import ERDiagram.AttributeType;
import ERDiagram.Entity;
import ERDiagram.EntityRelationDiagram;
import ERDiagram.MultiplicityType;
import ERDiagram.Relation;
import ERDiagram.RelationEnding;
import hu.bme.mit.mdsd.codegen.CheckConstraints;
import hu.bme.mit.mdsd.codegen.CodeGeneratorHelper;
import org.eclipse.emf.common.util.EList;
import org.eclipse.emf.ecore.resource.Resource;
import org.eclipse.xtend.lib.annotations.Accessors;
import org.eclipse.xtend2.lib.StringConcatenation;
import org.eclipse.xtext.xbase.lib.Exceptions;
import org.eclipse.xtext.xbase.lib.Functions.Function1;
import org.eclipse.xtext.xbase.lib.IterableExtensions;
import org.eclipse.xtext.xbase.lib.Pure;
import org.eclipse.xtext.xbase.lib.StringExtensions;

@SuppressWarnings("all")
public class EntitiesGenerator {
  private EntityRelationDiagram model;
  
  @Accessors
  private String packageName = "hu.bme.mit.mdsd.codegen.generated";
  
  public EntitiesGenerator(final EntityRelationDiagram model) {
    this.model = model;
  }
  
  public CharSequence createClassFromEntity(final Entity entity) {
    StringConcatenation _builder = new StringConcatenation();
    _builder.append("package ");
    _builder.append(this.packageName, "");
    _builder.append(";");
    _builder.newLineIfNotEmpty();
    _builder.newLine();
    {
      Iterable<RelationEnding> _relationEndings = this.getRelationEndings(entity);
      final Function1<RelationEnding, Boolean> _function = new Function1<RelationEnding, Boolean>() {
        public Boolean apply(final RelationEnding it) {
          MultiplicityType _multiplicity = it.getMultiplicity();
          return Boolean.valueOf(_multiplicity.equals(MultiplicityType.MANY));
        }
      };
      boolean _exists = IterableExtensions.<RelationEnding>exists(_relationEndings, _function);
      if (_exists) {
        _builder.append("import java.util.List;");
        _builder.newLine();
        _builder.append("import java.util.ArrayList;");
        _builder.newLine();
      }
    }
    _builder.newLine();
    _builder.append("class ");
    String _name = entity.getName();
    _builder.append(_name, "");
    _builder.append(" ");
    {
      EList<Entity> _isA = entity.getIsA();
      boolean _isEmpty = _isA.isEmpty();
      boolean _not = (!_isEmpty);
      if (_not) {
        _builder.append("extends ");
        EList<Entity> _isA_1 = entity.getIsA();
        Entity _get = _isA_1.get(0);
        String _name_1 = _get.getName();
        _builder.append(_name_1, "");
      }
    }
    _builder.append(" {");
    _builder.newLineIfNotEmpty();
    {
      EList<Attribute> _attributes = entity.getAttributes();
      for(final Attribute atr : _attributes) {
        _builder.append("\t");
        _builder.append("private ");
        AttributeType _type = atr.getType();
        String _name_2 = _type.getName();
        _builder.append(_name_2, "\t");
        _builder.append(" ");
        String _name_3 = atr.getName();
        _builder.append(_name_3, "\t");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
      }
    }
    _builder.append("\t");
    _builder.newLine();
    {
      EList<Attribute> _attributes_1 = entity.getAttributes();
      for(final Attribute atr_1 : _attributes_1) {
        _builder.append("\t");
        _builder.append("public ");
        AttributeType _type_1 = atr_1.getType();
        String _name_4 = _type_1.getName();
        _builder.append(_name_4, "\t");
        _builder.append(" get");
        String _name_5 = atr_1.getName();
        String _firstUpper = StringExtensions.toFirstUpper(_name_5);
        _builder.append(_firstUpper, "\t");
        _builder.append("() {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("return ");
        String _name_6 = atr_1.getName();
        _builder.append(_name_6, "\t\t");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
        _builder.append("\t");
        _builder.append("public void set");
        String _name_7 = atr_1.getName();
        String _firstUpper_1 = StringExtensions.toFirstUpper(_name_7);
        _builder.append(_firstUpper_1, "\t");
        _builder.append("(");
        AttributeType _type_2 = atr_1.getType();
        String _name_8 = _type_2.getName();
        _builder.append(_name_8, "\t");
        _builder.append(" ");
        String _name_9 = atr_1.getName();
        _builder.append(_name_9, "\t");
        _builder.append(") {");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("\t");
        _builder.append("this.");
        String _name_10 = atr_1.getName();
        _builder.append(_name_10, "\t\t");
        _builder.append(" = ");
        String _name_11 = atr_1.getName();
        _builder.append(_name_11, "\t\t");
        _builder.append(";");
        _builder.newLineIfNotEmpty();
        _builder.append("\t");
        _builder.append("}");
        _builder.newLine();
        _builder.append("\t");
        _builder.newLine();
      }
    }
    {
      Iterable<RelationEnding> _relationEndings_1 = this.getRelationEndings(entity);
      for(final RelationEnding relationEnding : _relationEndings_1) {
        {
          MultiplicityType _multiplicity = relationEnding.getMultiplicity();
          boolean _equals = _multiplicity.equals(MultiplicityType.MANY);
          if (_equals) {
            _builder.append("\t");
            _builder.append("private List<");
            Entity _target = relationEnding.getTarget();
            String _name_12 = _target.getName();
            _builder.append(_name_12, "\t");
            _builder.append("> ");
            String _name_13 = relationEnding.getName();
            _builder.append(_name_13, "\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("public List<");
            Entity _target_1 = relationEnding.getTarget();
            String _name_14 = _target_1.getName();
            _builder.append(_name_14, "\t");
            _builder.append("> get");
            String _name_15 = relationEnding.getName();
            String _firstUpper_2 = StringExtensions.toFirstUpper(_name_15);
            _builder.append(_firstUpper_2, "\t");
            _builder.append("() {");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("if (");
            String _name_16 = relationEnding.getName();
            _builder.append(_name_16, "\t\t");
            _builder.append(" == null)");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t\t");
            String _name_17 = relationEnding.getName();
            _builder.append(_name_17, "\t\t\t");
            _builder.append(" = new ArrayList<");
            Entity _target_2 = relationEnding.getTarget();
            String _name_18 = _target_2.getName();
            _builder.append(_name_18, "\t\t\t");
            _builder.append(">();");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("return ");
            String _name_19 = relationEnding.getName();
            _builder.append(_name_19, "\t\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          } else {
            _builder.append("\t");
            _builder.append("private ");
            Entity _target_3 = relationEnding.getTarget();
            String _name_20 = _target_3.getName();
            _builder.append(_name_20, "\t");
            _builder.append(" ");
            String _name_21 = relationEnding.getName();
            _builder.append(_name_21, "\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("public ");
            Entity _target_4 = relationEnding.getTarget();
            String _name_22 = _target_4.getName();
            _builder.append(_name_22, "\t");
            _builder.append(" get");
            String _name_23 = relationEnding.getName();
            String _firstUpper_3 = StringExtensions.toFirstUpper(_name_23);
            _builder.append(_firstUpper_3, "\t");
            _builder.append("() {");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("return ");
            String _name_24 = relationEnding.getName();
            _builder.append(_name_24, "\t\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
            _builder.append("\t");
            _builder.append("public void set");
            String _name_25 = relationEnding.getName();
            String _firstUpper_4 = StringExtensions.toFirstUpper(_name_25);
            _builder.append(_firstUpper_4, "\t");
            _builder.append("(");
            Entity _target_5 = relationEnding.getTarget();
            String _name_26 = _target_5.getName();
            _builder.append(_name_26, "\t");
            _builder.append(" ");
            String _name_27 = relationEnding.getName();
            _builder.append(_name_27, "\t");
            _builder.append(") {");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("\t");
            _builder.append("this.");
            String _name_28 = relationEnding.getName();
            _builder.append(_name_28, "\t\t");
            _builder.append(" = ");
            String _name_29 = relationEnding.getName();
            _builder.append(_name_29, "\t\t");
            _builder.append(";");
            _builder.newLineIfNotEmpty();
            _builder.append("\t");
            _builder.append("}");
            _builder.newLine();
            _builder.append("\t");
            _builder.newLine();
          }
        }
      }
    }
    _builder.append("}");
    _builder.newLine();
    return _builder;
  }
  
  public Iterable<RelationEnding> getRelationEndings(final Entity entity) {
    EList<Relation> _relations = this.model.getRelations();
    final Function1<Relation, Boolean> _function = new Function1<Relation, Boolean>() {
      public Boolean apply(final Relation it) {
        boolean _or = false;
        RelationEnding _leftEnding = it.getLeftEnding();
        Entity _target = _leftEnding.getTarget();
        boolean _equals = _target.equals(entity);
        if (_equals) {
          _or = true;
        } else {
          RelationEnding _rightEnding = it.getRightEnding();
          Entity _target_1 = _rightEnding.getTarget();
          boolean _equals_1 = _target_1.equals(entity);
          _or = _equals_1;
        }
        return Boolean.valueOf(_or);
      }
    };
    Iterable<Relation> _filter = IterableExtensions.<Relation>filter(_relations, _function);
    final Function1<Relation, RelationEnding> _function_1 = new Function1<Relation, RelationEnding>() {
      public RelationEnding apply(final Relation it) {
        RelationEnding _xblockexpression = null;
        {
          RelationEnding _leftEnding = it.getLeftEnding();
          Entity _target = _leftEnding.getTarget();
          boolean _equals = _target.equals(entity);
          if (_equals) {
            it.getRightEnding();
          }
          _xblockexpression = it.getLeftEnding();
        }
        return _xblockexpression;
      }
    };
    return IterableExtensions.<Relation, RelationEnding>map(_filter, _function_1);
  }
  
  public void generateEntities() {
    try {
      EList<Entity> _entities = this.model.getEntities();
      for (final Entity entity : _entities) {
        Resource _eResource = this.model.eResource();
        String _name = entity.getName();
        String _firstUpper = StringExtensions.toFirstUpper(_name);
        CharSequence _createClassFromEntity = this.createClassFromEntity(entity);
        CodeGeneratorHelper.createJavaFile(_eResource, this.packageName, _firstUpper, _createClassFromEntity);
      }
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  public boolean checkConstraints() {
    try {
      return CheckConstraints.checkConstraints(this.model);
    } catch (Throwable _e) {
      throw Exceptions.sneakyThrow(_e);
    }
  }
  
  @Pure
  public String getPackageName() {
    return this.packageName;
  }
  
  public void setPackageName(final String packageName) {
    this.packageName = packageName;
  }
}
