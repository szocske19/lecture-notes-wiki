package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Habitation extends Place {
	
	private List<Student> resident;
	
	public List<Student> getResident() {
		if (resident == null)
			resident = new ArrayList<Student>();
		return resident;
	}
	
}
