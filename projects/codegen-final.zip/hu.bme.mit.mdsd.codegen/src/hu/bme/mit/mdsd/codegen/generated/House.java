package hu.bme.mit.mdsd.codegen.generated;


class House extends Building {
	
}
