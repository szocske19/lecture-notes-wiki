package hu.bme.mit.mdsd.codegen.generated;


class DanceHall extends Recreation {
	
}
