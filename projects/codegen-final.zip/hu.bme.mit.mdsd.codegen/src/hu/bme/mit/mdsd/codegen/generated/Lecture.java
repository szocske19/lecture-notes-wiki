package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Lecture  {
	private String code;
	
	public String getCode() {
		return code;
	}
	
	public void setCode(String code) {
		this.code = code;
	}
	
	private List<Teacher> teacher;
	
	public List<Teacher> getTeacher() {
		if (teacher == null)
			teacher = new ArrayList<Teacher>();
		return teacher;
	}
	
	private Lecture lecture;
	
	public Lecture getLecture() {
		return lecture;
	}
	
	public void setLecture(Lecture lecture) {
		this.lecture = lecture;
	}
	
}
