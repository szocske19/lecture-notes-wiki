package hu.bme.mit.mdsd.codegen.generated;


class ScheduleItem  {
	private java.util.Date when;
	
	public java.util.Date getWhen() {
		return when;
	}
	
	public void setWhen(java.util.Date when) {
		this.when = when;
	}
	
	private Course scheduleOf;
	
	public Course getScheduleOf() {
		return scheduleOf;
	}
	
	public void setScheduleOf(Course scheduleOf) {
		this.scheduleOf = scheduleOf;
	}
	
	private Room room;
	
	public Room getRoom() {
		return room;
	}
	
	public void setRoom(Room room) {
		this.room = room;
	}
	
}
