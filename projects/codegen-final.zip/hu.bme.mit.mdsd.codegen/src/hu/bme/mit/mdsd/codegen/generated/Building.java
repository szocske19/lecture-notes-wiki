package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Building extends Place {
	
	private List<Room> rooms;
	
	public List<Room> getRooms() {
		if (rooms == null)
			rooms = new ArrayList<Room>();
		return rooms;
	}
	
}
