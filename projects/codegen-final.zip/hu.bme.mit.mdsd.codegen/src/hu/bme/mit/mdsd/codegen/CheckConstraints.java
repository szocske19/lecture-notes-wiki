package hu.bme.mit.mdsd.codegen;

import hu.bme.mit.mdsd.erdiagram.patterns.RelationWithoutEndingsMatcher;
import hu.bme.mit.mdsd.erdiagram.patterns.util.RelationWithoutEndingsProcessor;
import hu.bme.mit.mdsd.erdiagram.patterns.util.RelationWithoutEndingsQuerySpecification;

import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.incquery.runtime.api.IncQueryEngine;
import org.eclipse.incquery.runtime.emf.EMFScope;
import org.eclipse.incquery.runtime.exception.IncQueryException;

import ERDiagram.Relation;

public class CheckConstraints {
	
	public static boolean checkConstraints(Notifier model) throws IncQueryException{
		EMFScope scope = new EMFScope(model);
		IncQueryEngine iqe = IncQueryEngine.on(scope);
		
		RelationWithoutEndingsMatcher matcher = iqe.getMatcher(RelationWithoutEndingsQuerySpecification.instance());
		
		matcher.forEachMatch(new RelationWithoutEndingsProcessor() {
			@Override
			public void process(Relation pRelation) {
				System.out.println("Relation without relation ending " + pRelation);
			}
		});

		if(matcher.countMatches() > 0){
			return false;
		}
		
		return true;
	}
}
