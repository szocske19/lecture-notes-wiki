package hu.bme.mit.mdsd.codegen.generated;


class Koncert extends Place {
	private String name;
	private java.util.Date time;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	public java.util.Date getTime() {
		return time;
	}
	
	public void setTime(java.util.Date time) {
		this.time = time;
	}
	
}
