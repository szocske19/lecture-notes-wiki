package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Teacher extends Person {
	
	private List<Teacher> teacher;
	
	public List<Teacher> getTeacher() {
		if (teacher == null)
			teacher = new ArrayList<Teacher>();
		return teacher;
	}
	
}
