package hu.bme.mit.mdsd.codegen.generated;


class Place  {
	private String address;
	
	public String getAddress() {
		return address;
	}
	
	public void setAddress(String address) {
		this.address = address;
	}
	
}
