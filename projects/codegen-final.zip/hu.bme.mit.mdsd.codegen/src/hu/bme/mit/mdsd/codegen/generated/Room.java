package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Room  {
	private String name;
	
	public String getName() {
		return name;
	}
	
	public void setName(String name) {
		this.name = name;
	}
	
	private List<Room> rooms;
	
	public List<Room> getRooms() {
		if (rooms == null)
			rooms = new ArrayList<Room>();
		return rooms;
	}
	
	private Room room;
	
	public Room getRoom() {
		return room;
	}
	
	public void setRoom(Room room) {
		this.room = room;
	}
	
}
