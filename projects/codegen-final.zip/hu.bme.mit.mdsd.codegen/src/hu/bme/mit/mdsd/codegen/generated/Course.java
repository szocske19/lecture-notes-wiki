package hu.bme.mit.mdsd.codegen.generated;

import java.util.List;
import java.util.ArrayList;

class Course  {
	private String courseName;
	
	public String getCourseName() {
		return courseName;
	}
	
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	
	private Lecture lecture;
	
	public Lecture getLecture() {
		return lecture;
	}
	
	public void setLecture(Lecture lecture) {
		this.lecture = lecture;
	}
	
	private List<Student> students;
	
	public List<Student> getStudents() {
		if (students == null)
			students = new ArrayList<Student>();
		return students;
	}
	
	private Course scheduleOf;
	
	public Course getScheduleOf() {
		return scheduleOf;
	}
	
	public void setScheduleOf(Course scheduleOf) {
		this.scheduleOf = scheduleOf;
	}
	
}
