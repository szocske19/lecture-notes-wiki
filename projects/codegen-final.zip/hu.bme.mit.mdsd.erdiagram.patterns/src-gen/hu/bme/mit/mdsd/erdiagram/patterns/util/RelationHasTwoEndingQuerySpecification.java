package hu.bme.mit.mdsd.erdiagram.patterns.util;

import com.google.common.collect.Sets;
import hu.bme.mit.mdsd.erdiagram.patterns.RelationHasTwoEndingMatch;
import hu.bme.mit.mdsd.erdiagram.patterns.RelationHasTwoEndingMatcher;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import org.eclipse.incquery.runtime.api.IncQueryEngine;
import org.eclipse.incquery.runtime.api.impl.BaseGeneratedEMFPQuery;
import org.eclipse.incquery.runtime.api.impl.BaseGeneratedEMFQuerySpecification;
import org.eclipse.incquery.runtime.exception.IncQueryException;
import org.eclipse.incquery.runtime.matchers.psystem.PBody;
import org.eclipse.incquery.runtime.matchers.psystem.PVariable;
import org.eclipse.incquery.runtime.matchers.psystem.basicdeferred.ExportedParameter;
import org.eclipse.incquery.runtime.matchers.psystem.basicenumerables.TypeBinary;
import org.eclipse.incquery.runtime.matchers.psystem.queries.PParameter;
import org.eclipse.incquery.runtime.matchers.psystem.queries.QueryInitializationException;

/**
 * A pattern-specific query specification that can instantiate RelationHasTwoEndingMatcher in a type-safe way.
 * 
 * @see RelationHasTwoEndingMatcher
 * @see RelationHasTwoEndingMatch
 * 
 */
@SuppressWarnings("all")
public final class RelationHasTwoEndingQuerySpecification extends BaseGeneratedEMFQuerySpecification<RelationHasTwoEndingMatcher> {
  private RelationHasTwoEndingQuerySpecification() {
    super(GeneratedPQuery.INSTANCE);
  }
  
  /**
   * @return the singleton instance of the query specification
   * @throws IncQueryException if the pattern definition could not be loaded
   * 
   */
  public static RelationHasTwoEndingQuerySpecification instance() throws IncQueryException {
    try{
    	return LazyHolder.INSTANCE;
    } catch (ExceptionInInitializerError err) {
    	throw processInitializerError(err);
    }
  }
  
  @Override
  protected RelationHasTwoEndingMatcher instantiate(final IncQueryEngine engine) throws IncQueryException {
    return RelationHasTwoEndingMatcher.on(engine);
  }
  
  @Override
  public RelationHasTwoEndingMatch newEmptyMatch() {
    return RelationHasTwoEndingMatch.newEmptyMatch();
  }
  
  @Override
  public RelationHasTwoEndingMatch newMatch(final Object... parameters) {
    return RelationHasTwoEndingMatch.newMatch((ERDiagram.Relation) parameters[0]);
  }
  
  private static class LazyHolder {
    private final static RelationHasTwoEndingQuerySpecification INSTANCE = make();
    
    public static RelationHasTwoEndingQuerySpecification make() {
      return new RelationHasTwoEndingQuerySpecification();					
    }
  }
  
  private static class GeneratedPQuery extends BaseGeneratedEMFPQuery {
    private final static RelationHasTwoEndingQuerySpecification.GeneratedPQuery INSTANCE = new GeneratedPQuery();
    
    @Override
    public String getFullyQualifiedName() {
      return "hu.bme.mit.mdsd.erdiagram.patterns.relationHasTwoEnding";
    }
    
    @Override
    public List<String> getParameterNames() {
      return Arrays.asList("relation");
    }
    
    @Override
    public List<PParameter> getParameters() {
      return Arrays.asList(new PParameter("relation", "ERDiagram.Relation"));
    }
    
    @Override
    public Set<PBody> doGetContainedBodies() throws QueryInitializationException {
      Set<PBody> bodies = Sets.newLinkedHashSet();
      try {
      {
      	PBody body = new PBody(this);
      	PVariable var_relation = body.getOrCreateVariableByName("relation");
      	PVariable var___0_ = body.getOrCreateVariableByName("_<0>");
      	PVariable var__virtual_0_ = body.getOrCreateVariableByName(".virtual{0}");
      	PVariable var___1_ = body.getOrCreateVariableByName("_<1>");
      	PVariable var__virtual_2_ = body.getOrCreateVariableByName(".virtual{2}");
      	body.setExportedParameters(Arrays.<ExportedParameter>asList(
      		new ExportedParameter(body, var_relation, "relation")
      	));
      	new TypeBinary(body, CONTEXT, var_relation, var__virtual_0_, getFeatureLiteral("erdiagram", "Relation", "leftEnding"), "erdiagram/Relation.leftEnding");
      	new TypeBinary(body, CONTEXT, var__virtual_0_, var___0_, getFeatureLiteral("erdiagram", "RelationEnding", "target"), "erdiagram/RelationEnding.target");
      	new TypeBinary(body, CONTEXT, var_relation, var__virtual_2_, getFeatureLiteral("erdiagram", "Relation", "rightEnding"), "erdiagram/Relation.rightEnding");
      	new TypeBinary(body, CONTEXT, var__virtual_2_, var___1_, getFeatureLiteral("erdiagram", "RelationEnding", "target"), "erdiagram/RelationEnding.target");
      	bodies.add(body);
      }
      	// to silence compiler error
      	if (false) throw new IncQueryException("Never", "happens");
      } catch (IncQueryException ex) {
      	throw processDependencyException(ex);
      }
      return bodies;
    }
  }
}
