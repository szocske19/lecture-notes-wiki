package hu.bme.mit.mdsd.erdiagram.patterns;

import ERDiagram.Relation;
import hu.bme.mit.mdsd.erdiagram.patterns.RelationWithoutEndingsMatch;
import hu.bme.mit.mdsd.erdiagram.patterns.util.RelationWithoutEndingsQuerySpecification;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;
import org.apache.log4j.Logger;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.incquery.runtime.api.IMatchProcessor;
import org.eclipse.incquery.runtime.api.IQuerySpecification;
import org.eclipse.incquery.runtime.api.IncQueryEngine;
import org.eclipse.incquery.runtime.api.impl.BaseMatcher;
import org.eclipse.incquery.runtime.exception.IncQueryException;
import org.eclipse.incquery.runtime.matchers.tuple.Tuple;
import org.eclipse.incquery.runtime.util.IncQueryLoggingUtil;

/**
 * Generated pattern matcher API of the hu.bme.mit.mdsd.erdiagram.patterns.relationWithoutEndings pattern,
 * providing pattern-specific query methods.
 * 
 * <p>Use the pattern matcher on a given model via {@link #on(IncQueryEngine)},
 * e.g. in conjunction with {@link IncQueryEngine#on(Notifier)}.
 * 
 * <p>Matches of the pattern will be represented as {@link RelationWithoutEndingsMatch}.
 * 
 * <p>Original source:
 * <code><pre>
 * pattern relationWithoutEndings(relation:Relation){
 * 	neg find relationHasTwoEnding(relation);
 * }
 * </pre></code>
 * 
 * @see RelationWithoutEndingsMatch
 * @see RelationWithoutEndingsProcessor
 * @see RelationWithoutEndingsQuerySpecification
 * 
 */
@SuppressWarnings("all")
public class RelationWithoutEndingsMatcher extends BaseMatcher<RelationWithoutEndingsMatch> {
  /**
   * Initializes the pattern matcher within an existing EMF-IncQuery engine.
   * If the pattern matcher is already constructed in the engine, only a light-weight reference is returned.
   * The match set will be incrementally refreshed upon updates.
   * @param engine the existing EMF-IncQuery engine in which this matcher will be created.
   * @throws IncQueryException if an error occurs during pattern matcher creation
   * 
   */
  public static RelationWithoutEndingsMatcher on(final IncQueryEngine engine) throws IncQueryException {
    // check if matcher already exists
    RelationWithoutEndingsMatcher matcher = engine.getExistingMatcher(querySpecification());
    if (matcher == null) {
    	matcher = new RelationWithoutEndingsMatcher(engine);
    	// do not have to "put" it into engine.matchers, reportMatcherInitialized() will take care of it
    }
    return matcher;
  }
  
  private final static int POSITION_RELATION = 0;
  
  private final static Logger LOGGER = IncQueryLoggingUtil.getLogger(RelationWithoutEndingsMatcher.class);
  
  /**
   * Initializes the pattern matcher over a given EMF model root (recommended: Resource or ResourceSet).
   * If a pattern matcher is already constructed with the same root, only a light-weight reference is returned.
   * The scope of pattern matching will be the given EMF model root and below (see FAQ for more precise definition).
   * The match set will be incrementally refreshed upon updates from this scope.
   * <p>The matcher will be created within the managed {@link IncQueryEngine} belonging to the EMF model root, so
   * multiple matchers will reuse the same engine and benefit from increased performance and reduced memory footprint.
   * @param emfRoot the root of the EMF containment hierarchy where the pattern matcher will operate. Recommended: Resource or ResourceSet.
   * @throws IncQueryException if an error occurs during pattern matcher creation
   * @deprecated use {@link #on(IncQueryEngine)} instead, e.g. in conjunction with {@link IncQueryEngine#on(Notifier)}
   * 
   */
  @Deprecated
  public RelationWithoutEndingsMatcher(final Notifier emfRoot) throws IncQueryException {
    this(IncQueryEngine.on(emfRoot));
  }
  
  /**
   * Initializes the pattern matcher within an existing EMF-IncQuery engine.
   * If the pattern matcher is already constructed in the engine, only a light-weight reference is returned.
   * The match set will be incrementally refreshed upon updates.
   * @param engine the existing EMF-IncQuery engine in which this matcher will be created.
   * @throws IncQueryException if an error occurs during pattern matcher creation
   * @deprecated use {@link #on(IncQueryEngine)} instead
   * 
   */
  @Deprecated
  public RelationWithoutEndingsMatcher(final IncQueryEngine engine) throws IncQueryException {
    super(engine, querySpecification());
  }
  
  /**
   * Returns the set of all matches of the pattern that conform to the given fixed values of some parameters.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @return matches represented as a RelationWithoutEndingsMatch object.
   * 
   */
  public Collection<RelationWithoutEndingsMatch> getAllMatches(final Relation pRelation) {
    return rawGetAllMatches(new Object[]{pRelation});
  }
  
  /**
   * Returns an arbitrarily chosen match of the pattern that conforms to the given fixed values of some parameters.
   * Neither determinism nor randomness of selection is guaranteed.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @return a match represented as a RelationWithoutEndingsMatch object, or null if no match is found.
   * 
   */
  public RelationWithoutEndingsMatch getOneArbitraryMatch(final Relation pRelation) {
    return rawGetOneArbitraryMatch(new Object[]{pRelation});
  }
  
  /**
   * Indicates whether the given combination of specified pattern parameters constitute a valid pattern match,
   * under any possible substitution of the unspecified parameters (if any).
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @return true if the input is a valid (partial) match of the pattern.
   * 
   */
  public boolean hasMatch(final Relation pRelation) {
    return rawHasMatch(new Object[]{pRelation});
  }
  
  /**
   * Returns the number of all matches of the pattern that conform to the given fixed values of some parameters.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @return the number of pattern matches found.
   * 
   */
  public int countMatches(final Relation pRelation) {
    return rawCountMatches(new Object[]{pRelation});
  }
  
  /**
   * Executes the given processor on each match of the pattern that conforms to the given fixed values of some parameters.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @param processor the action that will process each pattern match.
   * 
   */
  public void forEachMatch(final Relation pRelation, final IMatchProcessor<? super RelationWithoutEndingsMatch> processor) {
    rawForEachMatch(new Object[]{pRelation}, processor);
  }
  
  /**
   * Executes the given processor on an arbitrarily chosen match of the pattern that conforms to the given fixed values of some parameters.
   * Neither determinism nor randomness of selection is guaranteed.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @param processor the action that will process the selected match.
   * @return true if the pattern has at least one match with the given parameter values, false if the processor was not invoked
   * 
   */
  public boolean forOneArbitraryMatch(final Relation pRelation, final IMatchProcessor<? super RelationWithoutEndingsMatch> processor) {
    return rawForOneArbitraryMatch(new Object[]{pRelation}, processor);
  }
  
  /**
   * Returns a new (partial) match.
   * This can be used e.g. to call the matcher with a partial match.
   * <p>The returned match will be immutable. Use {@link #newEmptyMatch()} to obtain a mutable match object.
   * @param pRelation the fixed value of pattern parameter relation, or null if not bound.
   * @return the (partial) match object.
   * 
   */
  public RelationWithoutEndingsMatch newMatch(final Relation pRelation) {
    return RelationWithoutEndingsMatch.newMatch(pRelation);
  }
  
  /**
   * Retrieve the set of values that occur in matches for relation.
   * @return the Set of all values, null if no parameter with the given name exists, empty set if there are no matches
   * 
   */
  protected Set<Relation> rawAccumulateAllValuesOfrelation(final Object[] parameters) {
    Set<Relation> results = new HashSet<Relation>();
    rawAccumulateAllValues(POSITION_RELATION, parameters, results);
    return results;
  }
  
  /**
   * Retrieve the set of values that occur in matches for relation.
   * @return the Set of all values, null if no parameter with the given name exists, empty set if there are no matches
   * 
   */
  public Set<Relation> getAllValuesOfrelation() {
    return rawAccumulateAllValuesOfrelation(emptyArray());
  }
  
  @Override
  protected RelationWithoutEndingsMatch tupleToMatch(final Tuple t) {
    try {
    	return RelationWithoutEndingsMatch.newMatch((ERDiagram.Relation) t.get(POSITION_RELATION));
    } catch(ClassCastException e) {
    	LOGGER.error("Element(s) in tuple not properly typed!",e);
    	return null;
    }
  }
  
  @Override
  protected RelationWithoutEndingsMatch arrayToMatch(final Object[] match) {
    try {
    	return RelationWithoutEndingsMatch.newMatch((ERDiagram.Relation) match[POSITION_RELATION]);
    } catch(ClassCastException e) {
    	LOGGER.error("Element(s) in array not properly typed!",e);
    	return null;
    }
  }
  
  @Override
  protected RelationWithoutEndingsMatch arrayToMatchMutable(final Object[] match) {
    try {
    	return RelationWithoutEndingsMatch.newMutableMatch((ERDiagram.Relation) match[POSITION_RELATION]);
    } catch(ClassCastException e) {
    	LOGGER.error("Element(s) in array not properly typed!",e);
    	return null;
    }
  }
  
  /**
   * @return the singleton instance of the query specification of this pattern
   * @throws IncQueryException if the pattern definition could not be loaded
   * 
   */
  public static IQuerySpecification<RelationWithoutEndingsMatcher> querySpecification() throws IncQueryException {
    return RelationWithoutEndingsQuerySpecification.instance();
  }
}
