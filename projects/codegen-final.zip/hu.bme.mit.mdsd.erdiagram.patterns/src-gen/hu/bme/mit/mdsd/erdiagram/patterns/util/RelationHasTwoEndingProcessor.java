package hu.bme.mit.mdsd.erdiagram.patterns.util;

import ERDiagram.Relation;
import hu.bme.mit.mdsd.erdiagram.patterns.RelationHasTwoEndingMatch;
import org.eclipse.incquery.runtime.api.IMatchProcessor;

/**
 * A match processor tailored for the hu.bme.mit.mdsd.erdiagram.patterns.relationHasTwoEnding pattern.
 * 
 * Clients should derive an (anonymous) class that implements the abstract process().
 * 
 */
@SuppressWarnings("all")
public abstract class RelationHasTwoEndingProcessor implements IMatchProcessor<RelationHasTwoEndingMatch> {
  /**
   * Defines the action that is to be executed on each match.
   * @param pRelation the value of pattern parameter relation in the currently processed match
   * 
   */
  public abstract void process(final Relation pRelation);
  
  @Override
  public void process(final RelationHasTwoEndingMatch match) {
    process(match.getRelation());
  }
}
