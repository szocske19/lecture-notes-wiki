package hu.bme.mit.mdsd.erdiagram.patterns;

import hu.bme.mit.mdsd.erdiagram.patterns.RelationHasTwoEndingMatcher;
import hu.bme.mit.mdsd.erdiagram.patterns.RelationWithoutEndingsMatcher;
import hu.bme.mit.mdsd.erdiagram.patterns.util.RelationHasTwoEndingQuerySpecification;
import hu.bme.mit.mdsd.erdiagram.patterns.util.RelationWithoutEndingsQuerySpecification;
import org.eclipse.incquery.runtime.api.IncQueryEngine;
import org.eclipse.incquery.runtime.api.impl.BaseGeneratedPatternGroup;
import org.eclipse.incquery.runtime.exception.IncQueryException;

/**
 * A pattern group formed of all patterns defined in constraints.eiq.
 * 
 * <p>Use the static instance as any {@link org.eclipse.incquery.runtime.api.IPatternGroup}, to conveniently prepare
 * an EMF-IncQuery engine for matching all patterns originally defined in file constraints.eiq,
 * in order to achieve better performance than one-by-one on-demand matcher initialization.
 * 
 * <p> From package hu.bme.mit.mdsd.erdiagram.patterns, the group contains the definition of the following patterns: <ul>
 * <li>relationHasTwoEnding</li>
 * <li>relationWithoutEndings</li>
 * </ul>
 * 
 * @see IPatternGroup
 * 
 */
@SuppressWarnings("all")
public final class Constraints extends BaseGeneratedPatternGroup {
  /**
   * Access the pattern group.
   * 
   * @return the singleton instance of the group
   * @throws IncQueryException if there was an error loading the generated code of pattern specifications
   * 
   */
  public static Constraints instance() throws IncQueryException {
    if (INSTANCE == null) {
    	INSTANCE = new Constraints();
    }
    return INSTANCE;
  }
  
  private static Constraints INSTANCE;
  
  private Constraints() throws IncQueryException {
    querySpecifications.add(RelationHasTwoEndingQuerySpecification.instance());
    querySpecifications.add(RelationWithoutEndingsQuerySpecification.instance());
  }
  
  public RelationHasTwoEndingQuerySpecification getRelationHasTwoEnding() throws IncQueryException {
    return RelationHasTwoEndingQuerySpecification.instance();
  }
  
  public RelationHasTwoEndingMatcher getRelationHasTwoEnding(final IncQueryEngine engine) throws IncQueryException {
    return RelationHasTwoEndingMatcher.on(engine);
  }
  
  public RelationWithoutEndingsQuerySpecification getRelationWithoutEndings() throws IncQueryException {
    return RelationWithoutEndingsQuerySpecification.instance();
  }
  
  public RelationWithoutEndingsMatcher getRelationWithoutEndings(final IncQueryEngine engine) throws IncQueryException {
    return RelationWithoutEndingsMatcher.on(engine);
  }
}
