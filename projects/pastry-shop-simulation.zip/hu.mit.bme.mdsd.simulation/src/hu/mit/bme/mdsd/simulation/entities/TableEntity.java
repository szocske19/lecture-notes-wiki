package hu.mit.bme.mdsd.simulation.entities;

import desmoj.core.simulator.Entity;
import desmoj.core.simulator.Model;

public class TableEntity extends Entity{

	public TableEntity(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);
	}

}
