package hu.mit.bme.mdsd.simulation.entities;

import desmoj.core.simulator.Entity;
import desmoj.core.simulator.Model;

public class WaitressEntity extends Entity{

	public WaitressEntity(Model owner, String name, boolean showInTrace) {
		super(owner, name, showInTrace);
	}

}
